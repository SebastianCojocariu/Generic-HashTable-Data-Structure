#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MAX_LEN 25

void eliberare_valoare_materie(void *a);
void eliberare_valoare_student(void *a);
void eliberare_cheie_d(void *a);
void eliberare_cheie_s(void *a);
typedef unsigned int (*TF)(void *,char *);
typedef unsigned int (*TFHash)(const void*,size_t,size_t);
typedef void (*TFafisare)(void*,FILE *);
typedef int (*TFComp)(void*,void*);
typedef void(*TFeliberare)(void*);



typedef struct celulag
{
  void *info;
  struct celulag *urm;
} TCelulaG, *TLG, **ALG;


typedef struct
{
	char *nume;
	float medie;
	char grupa[6]; // 324CB + NULL
	int varsta;
} TStudent;


typedef struct
{
	char *materie;
	int ore_curs;
	int ore_lab;
	int credit;
	int teme;
} TMaterie;


typedef struct{
	TFHash f_hash;
	TLG *v;
	TFComp f_comp;
	TFafisare f_afisare_cheie;
	TFeliberare f_eliberare_cheie;
}HashTable;


typedef struct {
	void *valoare;
	void *cheie;
	TFafisare f_afisare_valoare;
	TFeliberare f_eliberare_valoare;
}Info_Celula;



void Dezaloca_TLG_Lista(TLG *aL , HashTable *hash );
void Dezaloca_TLG(TLG *aL , HashTable *hash );
void Adaugare_Element_Hash(HashTable *hash , TLG a , int nr_bucket , char semn , int * );