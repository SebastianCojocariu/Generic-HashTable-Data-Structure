#include "lib.h"


void Afisare_Student(void *a , FILE * out){
	TStudent *aux = ( TStudent* ) a;
	fprintf( out , "[Nume: %s, Grupa: %s, Medie: %.2f, Varsta: %d]" , aux->nume , aux->grupa , aux->medie , aux->varsta );
}

void Afisare_Materie(void *a,FILE *out){
	TMaterie *aux = ( TMaterie* ) a;
	fprintf( out , "[Materie: %s, Ore_curs: %d, Ore_lab: %d, Credit: %d, Teme: %d]" , aux->materie , aux->ore_curs , aux->ore_lab , aux->credit , aux->teme );
}

void Afisare_Cheie_s( void *a , FILE *out )
{
	
	Info_Celula *ax = ( Info_Celula* )a;
	fprintf( out , "%s" , (char*)ax -> cheie );
}


void Afisare_Cheie_d( void *a , FILE *out )
{
	Info_Celula *ax = ( Info_Celula* )a;

	fprintf( out , "%d" , *(int*)ax -> cheie );
}

int f_comp_chei_s( void *a , void *b )
{
	Info_Celula *ax = (Info_Celula*)a;
	Info_Celula *bx = (Info_Celula*)b; 

	return strcmp( (char*)bx -> cheie , (char*)ax -> cheie );

}

int f_comp_chei_d( void *a , void *b )
{
	Info_Celula *ax = (Info_Celula*)a;
	Info_Celula *bx = (Info_Celula*)b; 

  	return *(int*)ax -> cheie - *(int*)bx -> cheie;

}

unsigned int hash_f(const void *data, size_t len, size_t range) {
	unsigned int hash = 0u;
	size_t idx = 0;
	size_t cof = 1;
	size_t rate = 2;
	const char *d = (const char*)data;
	for(; idx < len; ++idx) {
		hash += d[idx] * cof;
		cof *= rate;
	}
	return hash % range;
}



void print( HashTable *hash , size_t nr_bucket , FILE *out )
{
	TLG aux;
	int i = 0;
	for( ; i < nr_bucket ; i++ )
	{
		fprintf( out , "[%d] :" , i );
		for( aux = hash -> v[ i ]; aux != NULL ; aux = aux -> urm)
		{   fprintf( out , " (" );
			Info_Celula *x = ( Info_Celula* )(aux -> info);
			hash -> f_afisare_cheie( aux -> info, out);
			fprintf( out , " -> " );
			x -> f_afisare_valoare ( x -> valoare , out );

			fprintf( out , ")" );
			
		}
	fprintf( out , "\n" );
	}

}



void *citire_student_materie( FILE *in , int d )
 {
	if( d == 1 )
	{
	
		TStudent *aux = malloc ( sizeof( TStudent ) );
		aux -> nume = malloc( MAX_LEN) ;
		fscanf( in , "%s" , aux -> nume );
		fscanf( in , "%f" , &aux -> medie );
		fscanf( in , "%s" , aux -> grupa );
		fscanf( in , "%d" , &aux -> varsta );


		void * x = aux;
		return x;
	}

	if( d == 2 )
	{
		
		TMaterie *aux = malloc ( sizeof( TMaterie ) );
		aux -> materie = malloc ( MAX_LEN );
		fscanf( in , "%s" , aux -> materie );
		fscanf( in , "%d" , &aux -> ore_curs );
		fscanf( in , "%d" , &aux -> ore_lab );
		fscanf( in , "%d" , &aux -> credit );
		fscanf( in , "%d" , &aux -> teme );
		void *x = aux; 
		return x;
	}
}



TLG aloca_celula( FILE *in , char semn ){
	void *cheie;
	if( semn == 'd' )
	{
		cheie = malloc ( sizeof( int ) );
		fscanf( in , "%d" , (int*)cheie );
	}
	else
	{
		cheie = malloc ( MAX_LEN );
		fscanf( in , "%s" , (char*)cheie );
	}

	char tip[12];
	fscanf( in , "%s" , tip );


	void *a;
	TLG aux = malloc ( sizeof( TCelulaG ) );

	if( strcmp ( tip , "stud" ) == 0 )
	{

		a = citire_student_materie( in , 1 );
		Info_Celula *x = malloc ( sizeof ( Info_Celula ) );

		x -> valoare = a;
		x -> cheie = cheie;

		x -> f_afisare_valoare = Afisare_Student;
		x -> f_eliberare_valoare = eliberare_valoare_student;

		aux -> info=x;
		aux -> urm=NULL;

	}


	if( strcmp ( tip , "mat" ) == 0)
	{

		a = citire_student_materie( in , 2 );
		Info_Celula *x = malloc ( sizeof ( Info_Celula ) );
		x -> valoare = a;

		x -> cheie = cheie;

		x -> f_afisare_valoare = Afisare_Materie;
		x -> f_eliberare_valoare = eliberare_valoare_materie;
		aux -> info = x;
		aux -> urm = NULL;

	}
	return aux;
}




HashTable *Init( size_t d , char semn ){
	HashTable *aux = malloc ( sizeof ( HashTable ) );
	if( !aux ) 
		return NULL;
	aux -> v = malloc ( d * sizeof ( TLG ) );
	if( !aux -> v )
	{
		free( aux );
		return NULL;
	}
	int i = 0;
	for( i = 0 ; i < d ; i++ )
	{
		
		aux -> v[i] = NULL;

	}

	aux -> f_hash = hash_f;
	
	if( semn == 's' )
	{
		aux -> f_comp = f_comp_chei_s;
		aux -> f_afisare_cheie = Afisare_Cheie_s;
		aux -> f_eliberare_cheie = eliberare_cheie_s;
	}	
	else if( semn =='d' )
	{

		aux -> f_comp = f_comp_chei_d;
		aux -> f_afisare_cheie = Afisare_Cheie_d;
		aux -> f_eliberare_cheie = eliberare_cheie_d;
	}
	

	return aux;
}




void Dezaloca_Hash( HashTable **x , int nr_bucket )
{
	HashTable *aux = *x;
	aux -> f_hash = NULL;
	aux -> f_comp = NULL;
	aux -> f_eliberare_cheie = NULL;

	int i;
	
	for( i = 0 ; i < nr_bucket ; i++ )
	{
	
		Dezaloca_TLG_Lista( &aux -> v[i] , aux );
	}
	free( aux -> v );
	free( *x );


}


HashTable* Realocare_Hash ( HashTable* hash , int* nr_bucket , char semn , int *nr_elemente_hash )
{
	*nr_elemente_hash = 0;
	HashTable* aux = Init ( 2 * (*nr_bucket), semn );
	int i;
	TLG x, y;
	for ( i = 0; i < *nr_bucket ; i++ )
	{
		x = hash -> v[i];
		while ( x != NULL)
		{
			y = x;
			x = x -> urm;
			y -> urm = NULL;
			
			Adaugare_Element_Hash ( aux , y , 2*(*nr_bucket) , semn, nr_elemente_hash );

		}
		hash -> v[i] = NULL;
	}
	Dezaloca_Hash( &hash , *nr_bucket);
	*nr_bucket = 2 * (*nr_bucket);

	return aux;

}

void Adaugare_Element_Hash(HashTable *hash,TLG a,int nr_bucket,char semn,int *nr_elemente_hash)

{	int cod;
	Info_Celula *aux = ( Info_Celula* ) a->info;
	if( semn == 'd')
		cod = hash -> f_hash( aux -> cheie , sizeof(int) , nr_bucket );
	
	if( semn == 's')
		cod = hash -> f_hash( aux -> cheie , strlen( aux -> cheie ) , nr_bucket );

	
	TLG copie = hash->v[cod] , ant = NULL;
	for( ; copie != NULL ; ant = copie , copie = copie -> urm)
	{
		if( hash -> f_comp( a -> info , copie -> info) == 0)
		{
			
			break;
		}

	}

	if ( ant == NULL && copie == NULL )
	{
		hash -> v[cod] = a;
		( *nr_elemente_hash )++;
		

	} 
	else if( ant == NULL )
		{

			hash -> v[cod] = a;
			a -> urm = copie -> urm;
			
			//Dezaloca_TLG( &copie , hash );
			
		}

	else if( copie == NULL )
	{
		ant -> urm = a;
		a -> urm = NULL;
		( *nr_elemente_hash )++;
		
		
	}

	else{
		a -> urm = copie -> urm;
		ant -> urm = a;
		
		//Dezaloca_TLG( &copie , hash );
		

	}


}


void delete( HashTable *hash , void *cheie , char semn , int nr_bucket , int *nr_elemente_hash )
{

	int cod;	
			
	if(semn == 's')
	{
			
		cod = hash -> f_hash( cheie , strlen( cheie ) , nr_bucket );

	}
	if(semn == 'd')
	{
	
		cod = hash -> f_hash( cheie , sizeof (int) , nr_bucket );

	
	}

	Info_Celula *info = malloc( sizeof ( Info_Celula ) ); ////TREBUIE DEZALOCAT
	
	info -> cheie = cheie ;
	
	int i = 0;
	
	TLG copie = hash -> v[cod] , ant = NULL ;
	
	for( ; copie != NULL ; ant = copie , copie = copie -> urm)
	{
		i++;

		if( hash -> f_comp( info , copie -> info ) ==0 )
		{
			
			break;
		}

	}

	if (ant == NULL && copie == NULL)
	{
		return;

	} 
	
	else if( ant == NULL )
	{

 		hash -> v [ cod ] = copie -> urm;
			
		(*nr_elemente_hash)--;
			//Dezaloca_TLG(&copie,hash);
		
	}

	else if( copie == NULL )
	{
		return;
	}

	else
	{
		
		ant -> urm = copie -> urm;
		( *nr_elemente_hash )--;
		//Dezaloca_TLG(&copie,hash);
		

	}




}




int main(){

	FILE *out = fopen ( "output.out" , "w" );
	FILE *in = fopen ( "input.in" , "r" );
	int nr_bucket , nr_linii ,nr_elemente_hash = 0 ;
	float load_factor;
	char semn;
	char operatie[12];
	fscanf( in , "%s\n" , operatie ); //citim inithash
	                     
	fscanf( in , "%c " , &semn ); // citim 'd' sau 's'
	
	fscanf( in , "%d " , &nr_bucket );  //citim cate bucketuri se dau initial
	
	fscanf( in , "%d " , &nr_linii );  //citim nr de linii;

	HashTable *hash = Init ( nr_bucket , semn );
	

	int i;
	for( i = 0 ; i < nr_linii ; i++ )
	{

		fscanf( in , "%s" , operatie );

		if( strcmp ( operatie , "insert" ) == 0 )
		{
			
			TLG a = aloca_celula( in , semn );

			Adaugare_Element_Hash( hash , a , nr_bucket , semn , &nr_elemente_hash );
			load_factor = ((float)nr_elemente_hash) / nr_bucket;

			if( load_factor >= 3./4 )
				hash = Realocare_Hash( hash , &nr_bucket , semn , &nr_elemente_hash );


		}

		if( strcmp ( operatie , "print" ) == 0)
		{
			
			print( hash , nr_bucket , out);
		}
		

		if( strcmp ( operatie , "find" ) == 0 )
		{
			
			int cod,ok = 1;
			void *a;
			Info_Celula *aux = malloc ( sizeof ( Info_Celula ) );
			if(semn == 's' )
			{
				a = malloc( MAX_LEN );
				fscanf( in , "%s" , a );
				cod = hash -> f_hash( a , strlen( a ) , nr_bucket );

			}
			if( semn == 'd' )
			{
				a = malloc ( sizeof ( int ) );
				fscanf( in , "%d" , a );
				cod = hash -> f_hash( a , sizeof ( int ) , nr_bucket) ;
				
			}
			
			aux -> cheie = a; //trebuie sa o dezalocam la sfarsit!!!!
			TLG x;
			for(x = hash -> v[ cod ] ; x != NULL ; x = x -> urm )
			{
				if( hash -> f_comp( aux , x -> info ) ==0 )
				{   ok = 0;
					Info_Celula *info = ( Info_Celula* )x -> info;
					info -> f_afisare_valoare( info -> valoare , out );
					fprintf( out , "\n" );
				}

			}
			if( ok == 1 ) 
				fprintf( out , "Nu exista\n" );

		}
		
		

		if( strcmp ( operatie , "delete" ) == 0)
		{
			
			void *a;
			
			if( semn == 's' )
			{
				a = malloc ( MAX_LEN );
				fscanf( in , "%s" , a );
				

			}
			if( semn == 'd' )
			{
				a = malloc ( sizeof ( int ) );
				fscanf( in , "%d" , a );
				
			}
			delete( hash , a , semn , nr_bucket , &nr_elemente_hash );




		}


	}

	fclose(out);
	fclose(in);



}

