#include "lib.h"



void eliberare_valoare_student( void *a )
{

	TStudent *x = ( TStudent* )a;
	free ( x -> nume );
	free ( x -> grupa );
	free ( x );
}

void eliberare_valoare_materie( void *a)
{

	TMaterie *x = ( TMaterie* )a;
	free( x -> materie );
	free( x );
}

void eliberare_cheie_d( void *a )
{

	TLG x = ( TLG )a;
	Info_Celula* aux = ( Info_Celula* ) x -> info;
	
	free( ( int* ) aux -> cheie );
	
}
void eliberare_cheie_s( void *a )
{

	TLG x = ( TLG )a;
	Info_Celula* aux = ( Info_Celula* ) x -> info;
	
		free( ( char* ) aux -> cheie );
}

void eliberare_info_din_tlg( HashTable *hash , TLG a)
{
	Info_Celula *aux = ( Info_Celula* ) a -> info;
	aux -> f_eliberare_valoare(aux -> valoare);
	hash -> f_eliberare_cheie((void*)a);
	aux -> f_afisare_valoare = NULL;
	aux -> f_eliberare_valoare = NULL;	

}

void Dezaloca_TLG( TLG *aL , HashTable *hash )
{

	eliberare_info_din_tlg( hash , *aL );
	( *aL ) -> urm = NULL;
	*aL = NULL;

}

void Dezaloca_TLG_Lista(TLG *aL, HashTable *hash )
{

	TLG aux;
  	while( *aL )
  {
   		aux = *aL;
    	*aL = aux->urm;
    	Dezaloca_TLG( &aux , hash );
    
  }
}
